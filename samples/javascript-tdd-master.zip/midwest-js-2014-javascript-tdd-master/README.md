midwest-js-2014-javascript-tdd
==============================

My JavaScript TDD talk from MidwestJS 2014.


## Instructions

Clone the repository


Make sure all dependencies are available to the application:

```sh
$ npm install
$ bower install
```

To build the application

```sh
$ grunt build
```

To run the tests

```sh
$ grunt test
```

